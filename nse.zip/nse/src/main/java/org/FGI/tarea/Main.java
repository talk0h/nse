package org.FGI.tarea;

public class Main {
    public static void main(String[] args) {
        login lol = new login();
        lol.setVisible(true);
    }
}
